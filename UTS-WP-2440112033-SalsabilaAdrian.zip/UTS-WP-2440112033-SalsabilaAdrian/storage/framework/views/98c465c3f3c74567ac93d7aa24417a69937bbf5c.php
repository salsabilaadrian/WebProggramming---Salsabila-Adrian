<?php $__env->startSection('content'); ?>
    <div class="container text-light" style="background-color: gray">
        <h2>Book List</h2>
    </div>

    
    
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Computer Science\05\UTS\WP Try\UTS-WP-2440112033-SalsabilaAdrian\resources\views/booklist.blade.php ENDPATH**/ ?>
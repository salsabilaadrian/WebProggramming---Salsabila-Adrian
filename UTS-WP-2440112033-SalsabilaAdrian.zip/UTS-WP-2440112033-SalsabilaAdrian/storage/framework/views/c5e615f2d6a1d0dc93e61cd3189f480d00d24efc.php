<nav class="nav p-3 justify-content-between" style="background-color: orange">
    <div class="container text-center text-light">
        <h1>Giant Book Supplier</h1>
    </div>
</nav>

<nav>
    <nav class="navbar navbar-expand-lg" style="background-color: white">
        <div class="container d-flex justify-content-center">
            <div class="col">
                <div class="container-fluid">
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="#">Home</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    Category
                                </a>
                                <ul class="dropdown-menu">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="/category/<?php echo e($category->id); ?>"><?php echo e($category->name); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="/publisher">Publisher</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="/contact">Contact</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
    </nav>
</nav>
<?php /**PATH C:\Computer Science\05\UTS\WP Try\UTS-WP-2440112033-SalsabilaAdrian\resources\views/header.blade.php ENDPATH**/ ?>
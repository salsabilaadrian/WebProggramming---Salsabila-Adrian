@extends('navbar')
@section('navbar', 'Contact')
@section('content')
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    </head>

    <body>
        <div class="container text-light" style="background-color: gray">
            <h2>Contact</h2>
        </div>
        <div class="container mx-auto">
            @foreach ($publishers as $publisher)
                <div id="portfolio">
                    <div class="container text-light col-4" style="background-color: gray">
                        <div class="booklist">
                            <h2>{{ $publisher->name }}</h2>
                            <h2>Address - {{ $publisher->address }}</h2>
                            <h2>Phone - {{ $publisher->phone }}</h2>
                            <h2>Email - {{ $publisher->email }}</h2>
                        </div>
                    </div>
                    <div class="container mx-auto" style="width: 100rem;">
                        @foreach ($publisher->book as $book)
                            <div class="card-body">
                                <div id="portfolio">
                                    <div class="container col-4">
                                        <div class="card">
                                            <img src={{ $book->image }} alt="">
                                            <h5>{{ $book->title }}</>
                                            </h5>
                                            <h6>by</h6>
                                            <h5>{{ $book->author }}</h5>
                                            <a href="/{{ $book->id }}">Detail</a>
                                        </div>
                                    </div>
                        @endforeach

                        <div class="card1">
                            @php
                                for ($i = 1; $i <= 23; $i++) {
                                    echo '<br>';
                                }
                            @endphp
                        </div>
                    </div>
                </div>
            @endforeach
        </div>


        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
            integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
        </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js"
            integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous">
        </script>
    </body>
    @include('footer')

    </html>
@endsection

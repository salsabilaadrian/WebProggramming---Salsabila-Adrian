@extends('navbar')
@section('navbar', 'Home')
@section('content')
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    </head>

    <body>
        <div class="container text-light" style="background-color: gray">
            <h2>Book List</h2>
        </div>
        <div class="container mx-auto" style="padding-bottom: 30px; padding-top: 30px">
            <div class="row">
                @foreach ($books as $book)
                    <div class="col-4">
                        <div class="card">
                            <div class="card-body m-2">
                                <img src={{ $book->image }} class="card-img-top" alt="" style="size: 10px">
                                <h5 class="card-title">{{ $book->title }}</h5>
                                <h6>by</h6>
                                <h5 class="card-text">{{ $book->author }}</h5>
                                <a href="/{{ $book->id }}" class="btn btn-primary">Detail</a>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
            integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
        </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js"
            integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous">
        </script>
    </body>
    @include('footer')

    </html>
@endsection
